MOJA FORMA 1.3 — KOMPLETNA PACZKA PROJEKTU ANDROID

WERSJA
- applicationId: pl.mojaforma.app (pozostawiono bez zmian dla zgodności aktualizacji)
- versionCode: 4
- versionName: 1.3
- minimalny Android: API 23 (Android 6.0)
- ikona aplikacji: nowa ikona Moja Forma w zasobach mipmap, w tym wariant adaptacyjny Androida 8+

CO ZAWIERA PROJEKT
1. Start z podsumowaniem kalorii, wody, wagi i suplementów.
2. Rejestr wagi i obwodów oraz wykres zmian masy ciała.
3. Kalendarz posiłków, kalorie i makroskładniki.
4. Książka przepisów z kategoriami: śniadania, obiady, kolacje, przekąski i desery. Baza startowa jest rozszerzana bez dublowania przepisów już zapisanych.
5. Import przepisu ze zdjęcia przez OCR Google ML Kit.
6. Lokalna analiza zdjęcia posiłku przez ogólny model etykietowania obrazu. To nie jest wiarygodne rozpoznawanie składników, gramatur ani kalorii.
7. Szkic jadłospisu na 7 dni z zapisanych przepisów.
8. Lista zakupów generowana z planu, ręczne pozycje i szacowanie kosztu po wpisaniu cen.
9. Skanowanie kodu kreskowego ze zdjęcia przez Google ML Kit. Skaner odczytuje numer kodu; nazwa produktu i cena są uzupełniane ręcznie. Nie ma podłączonej bazy produktów.
10. Asystent offline oparty na regułach: podsumowanie kalorii/makro, propozycje jadłospisu i ogólne wskazówki treningowe.
11. Kalkulator BMI, BMR i szacowanego TDEE.
12. Dziennik treningowy z seriami, powtórzeniami, ciężarem, odpoczynkiem i notatkami.
13. Mapa grup mięśniowych i linki do wyszukiwania filmów instruktażowych.
14. Dziennik snu, regeneracji, kroków i aktywności (ręczne wpisy).
15. Zdjęcia sylwetki przechowywane lokalnie i porównanie dwóch zdjęć.
16. Osiągnięcia/badges, wykres wagi i zwijane menu nawigacyjne.
17. Przypomnienia z godziną i powtarzaniem widoczne w aplikacji.
18. Eksport i przywracanie kopii danych JSON.

WAŻNE OGRANICZENIA — UCZCIWY OPIS
- Asystent nie jest generatywnym modelem AI. Prawdziwa rozmowa z modelem AI wymaga zewnętrznego dostawcy i bezpiecznego serwera pośredniczącego. Nie umieszczaj klucza API w aplikacji.
- Analiza zdjęcia posiłku podaje wyłącznie ogólne etykiety wizualne. Nie wylicza wiarygodnie kalorii ani gramatur.
- Skanowanie kodu kreskowego działa ze zdjęcia z galerii. Nie jest to skaner działający na żywo z kamery i nie pobiera automatycznie nazwy produktu z katalogu.
- Przypomnienia zapisują się w aplikacji, ale nie wysyłają jeszcze powiadomień systemowych, gdy aplikacja jest zamknięta.
- Kroki, sen i regeneracja są wpisywane ręcznie. Nie ma jeszcze integracji Health Connect ani zegarka.
- Wykresy, BMI, BMR i TDEE są obliczeniami orientacyjnymi. Nie stanowią diagnozy ani porady medycznej.
- Automatyczny jadłospis jest szkicem z przepisów użytkownika. Sprawdź porcje, składniki, kalorie i alergeny.
- Ceny zakupów są szacowane na podstawie cen wpisanych ręcznie.
- Zdjęcia sylwetki zajmują miejsce w pamięci aplikacji i mogą powiększać kopię JSON.

AKTUALIZACJA I DANE
- Nie zmieniono applicationId: pl.mojaforma.app.
- Przed aktualizacją wyeksportuj kopię danych JSON z aplikacji.
- Nie czyść danych aplikacji i nie odinstalowuj starej wersji przed wykonaniem kopii.
- Android może odmówić aktualizacji, jeśli nowy APK będzie podpisany innym kluczem niż poprzedni. W takim przypadku nie usuwaj starej aplikacji bez kopii danych.
- Przy aktualizacji wersja została podniesiona do versionCode 4 / versionName 1.3.

BUDOWANIE PRZEZ GITHUB ACTIONS
1. Wgraj zawartość katalogu MojaFormaAndroid do głównego katalogu repozytorium (w tym katalog app oraz .github).
2. Otwórz GitHub → Actions (Działania).
3. Wybierz workflow „Build Moja Forma APK”.
4. Kliknij Run workflow (Uruchom proces), a następnie zielony przycisk potwierdzenia.
5. Po zakończeniu otwórz wykonany proces i pobierz artifact „moja-forma-apk”.
6. Rozpakuj pobrany plik i znajdź app-debug.apk.

W tej paczce nie ma gotowego APK — jest kompletny projekt źródłowy do zbudowania przez GitHub Actions.
