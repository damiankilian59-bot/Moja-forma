MOJA FORMA 1.1 — ROZSZERZONY PROJEKT ANDROID

W projekcie zachowano dotychczasowe funkcje aplikacji oraz dodano moduły:
- książka przepisów z kategoriami i startową bazą 25 przepisów,
- import przepisu ze zdjęcia i lokalny OCR Google ML Kit (bez wysyłania obrazu do internetu),
- tygodniowy szkic jadłospisu z zapisanych przepisów,
- lista zakupów z ręcznym uzupełnianiem cen i szacowaniem kosztu,
- dziennik treningowy: ćwiczenie, partia, serie, powtórzenia, ciężar, odpoczynek i notatki,
- mapa grup mięśniowych z linkami do wyszukania filmów instruktażowych,
- dziennik snu i regeneracji,
- ręczny dziennik kroków i aktywności,
- lokalny dziennik zdjęć sylwetki z datą i widokiem,
- eksport i przywracanie kopii danych JSON; w Androidzie zapis kopii przez okno systemowe.

WAŻNE OGRANICZENIA / UCZCIWY OPIS FUNKCJI:
1. Rozpoznawanie tekstu z fotografii przepisu działa lokalnie przez ML Kit. OCR może popełniać błędy; zawsze sprawdź składniki i gramatury.
2. Zdjęcie posiłku można przeanalizować lokalnym modelem etykietowania obrazu ML Kit. Podpowiada on ogólne etykiety wizualne, ale nie gwarantuje rozpoznania konkretnego dania, składników, gramatur ani kalorii. Pełna analiza dietetyczna przez generatywne AI wymaga zewnętrznego dostawcy modelu, klucza API i bezpiecznego pośrednika serwerowego. Nie wpisuj klucza API na stałe do aplikacji.
3. Asystent jest lokalny/regułowy, a nie pełnym modelem generatywnym.
4. Kroki, aktywność, sen i regeneracja są wpisywane ręcznie. Automatyczna synchronizacja z zegarkiem/Health Connect wymaga osobnej integracji i zgód Androida.
5. Zdjęcia sylwetki są kompresowane i przechowywane lokalnie w danych aplikacji. Kopie z dużą liczbą zdjęć mogą być duże. Zachowuj je w bezpiecznym miejscu.
6. Automatyczny jadłospis tworzy szkic na bazie zapisanych przepisów. Nie gwarantuje dopasowania kalorii/makro; przed użyciem sprawdź porcje, skład i wartości.
7. Koszt zakupów jest szacunkiem na podstawie cen wpisanych ręcznie przez użytkownika.

BUDOWANIE APK PRZEZ GITHUB ACTIONS:
1. Rozpakuj ZIP na komputerze lub wgraj jego zawartość do repozytorium GitHub (nie wgrywaj samego ZIP-a, jeśli workflow buduje bez rozpakowywania).
2. Zachowaj strukturę katalogów: app/, .github/, build.gradle, settings.gradle, gradle.properties.
3. Otwórz Actions → Build Moja Forma APK → Run workflow.
4. Po zakończeniu pobierz artifact moja-forma-apk.
5. Rozpakuj artifact i zainstaluj app-debug.apk.

AKTUALIZACJA ISTNIEJĄCEJ APLIKACJI:
- Przed aktualizacją wykonaj kopię JSON w Więcej → Lista zakupów / Kopia danych.
- Aplikacja ma applicationId pl.mojaforma.app i versionCode 2. Jeśli Android zgłosi konflikt podpisu, nie odinstalowuj starej aplikacji bez kopii danych.
- Jest to debug APK do prywatnego testowania, nie wersja do Google Play.
