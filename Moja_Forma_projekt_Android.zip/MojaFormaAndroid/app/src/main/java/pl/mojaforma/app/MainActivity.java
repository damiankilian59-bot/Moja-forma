package pl.mojaforma.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.widget.Toast;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import com.google.mlkit.vision.label.ImageLabel;
import com.google.mlkit.vision.label.ImageLabeling;
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final int PICK_RECIPE_IMAGE = 701;
    private static final int PICK_WEB_FILE = 702;
    private static final int SAVE_BACKUP = 703;
    private static final int PICK_MEAL_IMAGE = 704;
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private String pendingBackupContent;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        webView.addJavascriptInterface(new RecipeBridge(), "AndroidRecipe");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent = params.createIntent();
                try { startActivityForResult(intent, PICK_WEB_FILE); }
                catch (Exception e) { filePathCallback = null; return false; }
                return true;
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class RecipeBridge {
        @JavascriptInterface public void chooseRecipeImage() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("image/*");
                startActivityForResult(intent, PICK_RECIPE_IMAGE);
            });
        }
        @JavascriptInterface public void chooseMealImage() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("image/*");
                startActivityForResult(intent, PICK_MEAL_IMAGE);
            });
        }
        @JavascriptInterface public void saveBackup(String json) {
            runOnUiThread(() -> {
                pendingBackupContent = json;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, "MojaForma-kopia.json");
                try { startActivityForResult(intent, SAVE_BACKUP); }
                catch (Exception e) { pendingBackupContent = null; Toast.makeText(MainActivity.this, "Nie można otworzyć okna zapisu kopii.", Toast.LENGTH_LONG).show(); }
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_WEB_FILE && filePathCallback != null) {
            Uri[] results = (resultCode == RESULT_OK && data != null && data.getData() != null) ? new Uri[]{data.getData()} : null;
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
            return;
        }
        if (requestCode == SAVE_BACKUP) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingBackupContent != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out == null) throw new IllegalStateException("Brak dostępu do pliku");
                    out.write(pendingBackupContent.getBytes(StandardCharsets.UTF_8));
                    Toast.makeText(this, "Kopia Moja Forma została zapisana.", Toast.LENGTH_LONG).show();
                } catch (Exception e) { Toast.makeText(this, "Nie udało się zapisać kopii.", Toast.LENGTH_LONG).show(); }
            }
            pendingBackupContent = null;
            return;
        }
        if (requestCode == PICK_MEAL_IMAGE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri mealUri = data.getData();
            try {
                InputImage mealImage = InputImage.fromFilePath(this, mealUri);
                ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS).process(mealImage)
                    .addOnSuccessListener(labels -> sendMealLabels(labels, mealUri))
                    .addOnFailureListener(error -> sendMealLabelError(error.getMessage()));
            } catch (Exception e) { sendMealLabelError(e.getMessage()); }
            return;
        }
        if (requestCode != PICK_RECIPE_IMAGE || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            InputImage image = InputImage.fromFilePath(this, uri);
            TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(image)
                .addOnSuccessListener(result -> sendOcrResult(result, uri))
                .addOnFailureListener(error -> sendOcrError(error.getMessage()));
        } catch (Exception e) { sendOcrError(e.getMessage()); }
    }


    private void sendMealLabels(java.util.List<ImageLabel> labels, Uri uri) {
        JSONArray arr = new JSONArray();
        for (ImageLabel label : labels) {
            JSONObject item = new JSONObject();
            try { item.put("text", label.getText()); item.put("confidence", label.getConfidence()); }
            catch (Exception ignored) { }
            arr.put(item);
        }
        String encoded = android.util.Base64.encodeToString(arr.toString().getBytes(StandardCharsets.UTF_8), android.util.Base64.NO_WRAP);
        String photo = "";
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options(); bounds.inJustDecodeBounds = true;
            try (InputStream in = getContentResolver().openInputStream(uri)) { BitmapFactory.decodeStream(in, null, bounds); }
            int sample = 1; while (bounds.outWidth / sample > 900 || bounds.outHeight / sample > 900) sample *= 2;
            BitmapFactory.Options opts = new BitmapFactory.Options(); opts.inSampleSize = sample;
            Bitmap bitmap;
            try (InputStream in = getContentResolver().openInputStream(uri)) { bitmap = BitmapFactory.decodeStream(in, null, opts); }
            if (bitmap != null) { ByteArrayOutputStream out = new ByteArrayOutputStream(); bitmap.compress(Bitmap.CompressFormat.JPEG, 72, out); photo = android.util.Base64.encodeToString(out.toByteArray(), android.util.Base64.NO_WRAP); bitmap.recycle(); }
        } catch (Exception ignored) { }
        final String photoData = photo;
        runOnUiThread(() -> webView.evaluateJavascript("window.onMealImageLabels && window.onMealImageLabels(JSON.parse(atob('" + encoded + "')),'" + photoData + "')", null));
    }
    private void sendMealLabelError(String message) {
        String safe = message == null ? "Nie udało się przeanalizować zdjęcia" : message.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ");
        runOnUiThread(() -> webView.evaluateJavascript("window.onMealImageLabelError && window.onMealImageLabelError('" + safe + "')", null));
    }

    private void sendOcrResult(Text result, Uri uri) {
        String value = result.getText();
        String encoded = android.util.Base64.encodeToString(value.getBytes(StandardCharsets.UTF_8), android.util.Base64.NO_WRAP);
        String photo = "";
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options(); bounds.inJustDecodeBounds = true;
            try (InputStream in = getContentResolver().openInputStream(uri)) { BitmapFactory.decodeStream(in, null, bounds); }
            int sample = 1; while (bounds.outWidth / sample > 900 || bounds.outHeight / sample > 900) sample *= 2;
            BitmapFactory.Options opts = new BitmapFactory.Options(); opts.inSampleSize = sample;
            Bitmap bitmap;
            try (InputStream in = getContentResolver().openInputStream(uri)) { bitmap = BitmapFactory.decodeStream(in, null, opts); }
            if (bitmap != null) {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.JPEG, 72, out);
                photo = android.util.Base64.encodeToString(out.toByteArray(), android.util.Base64.NO_WRAP);
                bitmap.recycle();
            }
        } catch (Exception ignored) { }
        final String photoData = photo;
        runOnUiThread(() -> webView.evaluateJavascript("window.onRecipeOcrResult && window.onRecipeOcrResult(atob('" + encoded + "'),'" + photoData + "')", null));
    }
    private void sendOcrError(String message) {
        String safe = message == null ? "Nie udało się odczytać zdjęcia" : message.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ");
        runOnUiThread(() -> webView.evaluateJavascript("window.onRecipeOcrError && window.onRecipeOcrError('" + safe + "')", null));
    }
    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
