MOJA FORMA — projekt aplikacji Android

Projekt opakowuje istniejącą wersję HTML w prostą aplikację Android (WebView).
Aplikacja działa offline. Dane są przechowywane lokalnie w pamięci aplikacji.

Automatyczne zbudowanie APK przez GitHub:
1. Utwórz publiczne repozytorium GitHub (lub użyj już utworzonego).
2. Wgraj ZAWARTOŚĆ tego folderu do repozytorium, zachowując strukturę katalogów.
3. Otwórz zakładkę Actions.
4. Wybierz "Build Moja Forma APK" i kliknij "Run workflow" (albo zaczekaj na build po pushu).
5. Po zakończeniu otwórz wykonane zadanie (workflow run), znajdź sekcję Artifacts i pobierz "moja-forma-apk".
6. Wypakuj ZIP i zainstaluj app-debug.apk na telefonie. Android może zapytać o zgodę na instalację z tej przeglądarki/menedżera plików.

To jest debug APK do prywatnego testowania, nie podpisany pakiet do sklepu Google Play.
Przed instalacją zachowaj kopię zapasową danych z wersji HTML. Dane z pliku w Chrome nie są automatycznie przenoszone do tej aplikacji.
