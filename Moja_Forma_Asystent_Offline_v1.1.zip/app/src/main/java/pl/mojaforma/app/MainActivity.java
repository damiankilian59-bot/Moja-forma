package pl.mojaforma.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final int REQ_PICK_RECIPE_PHOTO = 4101;
    private WebView webView;
    private TextRecognizer recognizer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new OcrBridge(), "AndroidOCR");
        webView.loadUrl("file:///android_asset/index.html");
    }

    /** Most wywolywany z JavaScriptu: window.AndroidOCR.pickRecipePhoto() */
    private class OcrBridge {
        @JavascriptInterface
        public void pickRecipePhoto() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                    intent.setType("image/*");
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    startActivityForResult(Intent.createChooser(intent, "Wybierz zdjęcie przepisu"), REQ_PICK_RECIPE_PHOTO);
                }
            });
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_PICK_RECIPE_PHOTO) return;
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            callJs("onRecipeOcrStatus", "Anulowano wybór zdjęcia.");
            return;
        }
        Uri uri = data.getData();
        callJs("onRecipeOcrStatus", "Odczytuję tekst ze zdjęcia…");
        try {
            if (recognizer == null) {
                recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
            }
            InputImage image = InputImage.fromFilePath(this, uri);
            recognizer.process(image)
                .addOnSuccessListener(result -> callJs("onRecipeOcr", result.getText()))
                .addOnFailureListener(e -> callJs("onRecipeOcrStatus", "Nie udało się odczytać tekstu. Spróbuj wyraźniejszego zdjęcia."));
        } catch (Exception e) {
            callJs("onRecipeOcrStatus", "Nie udało się otworzyć zdjęcia.");
        }
    }

    private void callJs(final String function, final String arg) {
        final String js = "if(window." + function + ")window." + function + "(" + JSONObject.quote(arg) + ");";
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (webView != null) webView.evaluateJavascript(js, null);
            }
        });
    }

    @Override
    protected void onDestroy() {
        if (recognizer != null) recognizer.close();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
