# Serwer AI dla Moja Forma

## Wymagania
- Node.js 18 lub nowszy.
- Klucz API dostawcy zgodnego z formatem OpenAI Chat Completions.
- Model obsługujący obrazy, jeśli chcesz analizować zdjęcia posiłków (domyślnie `gpt-4o-mini`).
- Hosting z HTTPS. Nie wystawiaj serwera produkcyjnego po zwykłym HTTP.

## Uruchomienie
1. Skopiuj `.env.example` do `.env` na serwerze lub ustaw zmienne w panelu hostingu.
2. Ustaw `AI_API_KEY` jako tajną zmienną środowiskową.
3. Ustaw losowy, długi `AI_APP_TOKEN` (zalecane). Nie zapisuj go w publicznym repozytorium.
4. Opcjonalnie ustaw `AI_API_URL`, `AI_MODEL` i `PORT`.
5. Uruchom `npm start` albo `node server.js`.
6. Sprawdź `GET /health` — powinno zwrócić `{"status":"ok","service":"moja-forma-ai"}`.
7. Wystaw serwer przez HTTPS i wpisz jego adres oraz `AI_APP_TOKEN` w aplikacji.

Można użyć dołączonego `Dockerfile`.

## API
`POST /chat` przyjmuje JSON:
- `message` — pytanie użytkownika,
- `profile` — opcjonalny kontekst profilu,
- `todayMeals` — opcjonalna lista dzisiejszych posiłków,
- `imageBase64` — opcjonalne zdjęcie JPEG w base64 bez prefiksu `data:`.

Odpowiedź: `{ "answer": "..." }`.

Jeśli ustawiono `AI_APP_TOKEN`, żądanie musi zawierać nagłówek `Authorization: Bearer <AI_APP_TOKEN>`. Klucz `AI_API_KEY` służący do dostawcy AI pozostaje wyłącznie na serwerze.

## Prywatność i koszty
Gdy użytkownik uruchomi analizę zdjęcia, fotografia i treść pytania są wysyłane do skonfigurowanego serwera, a następnie do dostawcy modelu. Poinformuj użytkowników o tym w polityce prywatności. Zdjęcie może zawierać dane osobowe lub wrażliwe. Ustaw limity kosztów u dostawcy. Wbudowany limit żądań per IP jest prosty i pamięciowy; w produkcji dodaj reverse proxy, ograniczenia rozmiaru/ilości, monitoring i politykę retencji. Nie loguj zdjęć ani danych zdrowotnych.
