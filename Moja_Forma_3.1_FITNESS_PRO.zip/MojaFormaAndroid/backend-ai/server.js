// Minimalny serwer pośredniczący dla Moja Forma. Wymaga Node.js 18+.
// Klucz dostawcy AI pozostaje na serwerze — nigdy nie umieszczaj go w APK.
const http = require('node:http');
const API_URL = process.env.AI_API_URL || 'https://api.openai.com/v1/chat/completions';
const API_KEY = process.env.AI_API_KEY;
const MODEL = process.env.AI_MODEL || 'gpt-4o-mini';
const APP_TOKEN = process.env.AI_APP_TOKEN || ''; // Opcjonalny dodatkowy token dostępu do mostka
const PORT = Number(process.env.PORT || 8787);
const WINDOW_MS = 60_000, MAX_REQUESTS = 20, hits = new Map();
function send(res, status, body) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'POST, OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type, Authorization' });
  res.end(JSON.stringify(body));
}
const server = http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') return send(res, 204, {});
  if (req.method === 'GET' && req.url === '/health') return send(res, 200, { status: 'ok', service: 'moja-forma-ai' });
  if (req.method !== 'POST' || req.url !== '/chat') return send(res, 404, { error: 'Not found' });
  if (APP_TOKEN && req.headers.authorization !== `Bearer ${APP_TOKEN}`) return send(res, 401, { error: 'Unauthorized app client' });
  const ip = req.socket.remoteAddress || 'unknown';
  const now = Date.now(), recent = (hits.get(ip) || []).filter(t => now - t < WINDOW_MS);
  if (recent.length >= MAX_REQUESTS) return send(res, 429, { error: 'Too many requests' });
  recent.push(now); hits.set(ip, recent);
  if (!API_KEY) return send(res, 503, { error: 'AI_API_KEY is not configured on server' });
  let raw = '';
  req.on('data', chunk => { raw += chunk; if (raw.length > 12_000_000) req.destroy(); });
  req.on('end', async () => {
    try {
      const input = JSON.parse(raw || '{}');
      if (typeof input.message !== 'string' || !input.message.trim()) return send(res, 400, { error: 'message is required' });
      const context = JSON.stringify({ profile: input.profile || {}, todayMeals: input.todayMeals || [] }).slice(0, 7000);
      const userContent = [{ type: 'text', text: input.message.slice(0, 5000) }];
      if (typeof input.imageBase64 === 'string' && input.imageBase64.length > 100) {
        if (input.imageBase64.length > 10_500_000) return send(res, 413, { error: 'Image is too large' });
        userContent.push({ type: 'image_url', image_url: { url: 'data:image/jpeg;base64,' + input.imageBase64 } });
      }
      const upstream = await fetch(API_URL, {
        method: 'POST', headers: { 'Authorization': `Bearer ${API_KEY}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ model: MODEL, temperature: 0.3, messages: [
          { role: 'system', content: 'Jesteś asystentem aplikacji Moja Forma. Odpowiadaj po polsku, konkretnie i bezpiecznie. Nie diagnozuj chorób, nie zalecaj głodówek ani skrajnych diet. Informacje o kaloriach i porcjach ze zdjęć traktuj jako szacunki, podawaj niepewność. Kontekst użytkownika (JSON): ' + context },
          { role: 'user', content: userContent }
        ] })
      });
      const data = await upstream.json();
      if (!upstream.ok) return send(res, 502, { error: data.error?.message || `AI provider HTTP ${upstream.status}` });
      const answer = data.choices?.[0]?.message?.content;
      if (typeof answer !== 'string') return send(res, 502, { error: 'Unexpected AI provider response' });
      return send(res, 200, { answer });
    } catch (e) { return send(res, 500, { error: 'Request failed: ' + e.message }); }
  });
});
server.listen(PORT, () => console.log(`Moja Forma AI bridge listening on ${PORT}`));
