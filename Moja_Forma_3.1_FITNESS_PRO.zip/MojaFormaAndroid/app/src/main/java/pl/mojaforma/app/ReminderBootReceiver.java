package pl.mojaforma.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import java.util.Calendar;
import java.util.Map;

public class ReminderBootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent bootIntent) {
        Map<String, ?> values = context.getSharedPreferences("reminders", Context.MODE_PRIVATE).getAll();
        AlarmManager alarms = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarms == null) return;
        for (String key : values.keySet()) {
            if (!key.endsWith("_message")) continue;
            String id = key.substring(0, key.length() - 8);
            String message = context.getSharedPreferences("reminders", Context.MODE_PRIVATE).getString(id + "_message", "Przypomnienie Moja Forma");
            String time = context.getSharedPreferences("reminders", Context.MODE_PRIVATE).getString(id + "_time", "12:00");
            boolean daily = context.getSharedPreferences("reminders", Context.MODE_PRIVATE).getBoolean(id + "_daily", false);
            if (!daily) continue;
            try {
                String[] parts = time.split(":"); Calendar when = Calendar.getInstance();
                when.set(Calendar.HOUR_OF_DAY, Integer.parseInt(parts[0])); when.set(Calendar.MINUTE, Integer.parseInt(parts[1])); when.set(Calendar.SECOND, 0); when.set(Calendar.MILLISECOND, 0);
                if (when.getTimeInMillis() <= System.currentTimeMillis()) when.add(Calendar.DAY_OF_YEAR, 1);
                Intent intent = new Intent(context, ReminderReceiver.class); intent.putExtra("message", message); intent.putExtra("id", id); intent.putExtra("daily", true);
                PendingIntent pi = PendingIntent.getBroadcast(context, id.hashCode(), intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                alarms.setInexactRepeating(AlarmManager.RTC_WAKEUP, when.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pi);
            } catch (Exception ignored) { }
        }
    }
}
