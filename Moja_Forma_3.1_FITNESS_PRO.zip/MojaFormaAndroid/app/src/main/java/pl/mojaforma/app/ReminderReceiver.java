package pl.mojaforma.app;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

public class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) return;
        String message = intent.getStringExtra("message");
        if (message == null || message.trim().isEmpty()) message = "Czas na zaplanowaną czynność";
        Intent open = new Intent(context, MainActivity.class);
        PendingIntent content = PendingIntent.getActivity(context, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(context, "moja_forma_reminders") : new Notification.Builder(context);
        Notification notification = builder.setSmallIcon(R.mipmap.ic_launcher).setContentTitle("Moja Forma").setContentText(message).setAutoCancel(true).setContentIntent(content).build();
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        String id = intent.getStringExtra("id");
        if (manager != null) manager.notify(id == null ? 1 : id.hashCode(), notification);
        if (id != null && !intent.getBooleanExtra("daily", false)) {
            context.getSharedPreferences("reminders", Context.MODE_PRIVATE).edit()
                .remove(id + "_message").remove(id + "_time").remove(id + "_daily").apply();
        }
    }
}
