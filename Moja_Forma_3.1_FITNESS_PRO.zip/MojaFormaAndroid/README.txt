MOJA FORMA 3.1 – FITNESS PRO
==============================

Wersja: 3.1.0
Motyw: DARK + LIME (grafit, ciemna zieleń, limonkowe akcenty)
Identyfikator aplikacji: pl.mojaforma.app
Minimalny Android: 8.0 (API 26)

ZAWARTOŚĆ I FUNKCJE
-------------------
- Dziennik diety, kalendarz posiłków, cele kalorii i makroskładników.
- Książka przepisów: 72 przepisy startowe, przepisy własne i import tekstu ze zdjęcia (OCR).
- Planowanie posiłków, lista zakupów i szacowanie kosztów wpisanych produktów.
- Baza żywności: 67 produktów offline, wyszukiwarka, kategorie, sortowanie i dodawanie własnych produktów.
- Opcjonalne pobranie do 300 produktów z Open Food Facts; zapisane pozycje są dostępne offline.
- Skanowanie kodów kreskowych i wyszukiwanie produktu w Open Food Facts.
- Dziennik treningowy, historia ćwiczeń, interaktywna mapa mięśni przód/tył oraz katalog FITNESS PRO z instrukcjami techniki, oddechu, sprzętu, zakresów serii/powtórzeń i typowych błędów.
- Katalog zawiera 36 opisanych ćwiczeń dla głównych partii mięśniowych; każda karta ma schemat poglądowy, sprzęt, pozycję startową, wykonanie, oddech, błędy i zalecany zakres serii/powtórzeń.
- Moduły rozgrzewki, mobilności, rozciągania, regeneracji, przerw między seriami i podwójnej progresji obciążenia.
- Akademia treningu z planem FBW, seriami, powtórzeniami i zasadami progresji.
- Akademia żywienia, rozszerzony przewodnik suplementacyjny (białko, kreatyna, omega-3, witamina D, magnez i elektrolity) oraz sekcja „Mit czy prawda?” (24 zagadnienia).
- Waga, wymiary, wykres postępów, porównanie zdjęć sylwetki i analiza zmian zapisanych pomiarów.
- Sen, kroki i aktywność; opcjonalny odczyt kroków i snu z Health Connect.
- Przypomnienia systemowe jednorazowe i codzienne; codzienne przypomnienia są odtwarzane po restarcie telefonu.
- Osiągnięcia i odznaki, raporty 7/30 dni, eksport CSV, wydruk raportu oraz kopia/przywracanie JSON.
- Asystent offline oparty na zapisanych danych i regułach; opcjonalny asystent AI online przez własny serwer.

BAZA PRODUKTÓW I ŹRÓDŁA
-----------------------
- 67 pozycji bazowych jest dołączonych lokalnie.
- Przycisk „Pobierz rozszerzoną bazę produktów” pobiera do 300 pozycji z Open Food Facts (maksymalnie 3 zapytania, po 100 wyników), filtruje produkty bez podstawowych wartości odżywczych, usuwa duplikaty i zapisuje wynik lokalnie.
- Katalog może zawierać do około 367 produktów plus produkty dodane ręcznie.
- Wartości Open Food Facts są społecznościowe, mogą być niepełne lub błędne; etykieta konkretnego produktu ma pierwszeństwo.
- Atrybucja: Open Food Facts. Baza: ODbL 1.0; zawartość: DbCL 1.0. Aplikacja identyfikuje się w User-Agent jako MojaForma/3.1 (Android app). API v2 jest obecnie oznaczone jako przestarzałe, ale pozostaje wersją obsługującą filtrowane wyszukiwanie strukturalne; pobranie wykonuje maksymalnie 3 zapytania, poniżej limitu 10 zapytań wyszukiwania na minutę na użytkownika.

AI ONLINE – OPCJONALNE
----------------------
Asystent offline działa bez konfiguracji. Generatywne odpowiedzi AI i analiza zdjęć przez model AI wymagają własnego serwera HTTPS. Backend znajduje się w katalogu backend-ai. Ustaw AI_API_KEY jako tajną zmienną środowiskową hostingu; opcjonalnie ustaw AI_APP_TOKEN. Klucza dostawcy AI nie wolno umieszczać w APK ani w repozytorium. Dostępność i koszt modelu zależą od dostawcy i konta. Użytkownik musi w aplikacji podać adres serwera i wyrazić zgodę na wysyłanie danych.

HEALTH CONNECT
--------------
Integracja wymaga Androida 9/API 28 lub nowszego oraz dostępnej usługi Health Connect. Użytkownik sam nadaje zgodę na odczyt kroków i snu. Dane są pobierane na pierwszym planie po uruchomieniu aplikacji lub ręcznym odświeżeniu; nie ma ciągłego odczytu w tle. Źródłowa aplikacja lub zegarek musi zapisywać dane do Health Connect.

DANE I AKTUALIZACJA
-------------------
Dane aplikacji są przechowywane lokalnie w WebView pod kluczem mojForma. Identyfikator pl.mojaforma.app pozostaje bez zmian, a wersja aplikacji to 3.1.0 (versionCode 31). Przed aktualizacją zalecamy wyeksportować kopię JSON. Możliwość aktualizacji bez odinstalowania zależy od podpisu APK; nie odinstalowuj poprzedniej wersji, jeśli Android zgłasza niezgodny podpis.

BUDOWANIE
---------
Projekt używa Android Gradle Plugin 8.10.1, Gradle 8.11.1, Kotlin 2.1.20, compileSdk 36 i JDK 17. GitHub Actions buduje wariant debug poleceniem gradle assembleDebug i publikuje artefakt moja-forma-apk. APK nie jest dołączone do ZIP-a; powstaje dopiero po pomyślnym wykonaniu workflow.

Wykonane kontrole statyczne: składnia JavaScript aplikacji i serwera Node.js, brak powielonych identyfikatorów HTML, obecność wymaganych sekcji, parsowanie XML oraz integralność archiwum ZIP. Środowisko przygotowania nie zawiera Android SDK ani Gradle, dlatego nie wykonano lokalnej kompilacji APK. Kompilację Android należy potwierdzić w GitHub Actions przed instalacją. Schematy ćwiczeń są ilustracjami poglądowymi, a nie indywidualną analizą techniki użytkownika.
