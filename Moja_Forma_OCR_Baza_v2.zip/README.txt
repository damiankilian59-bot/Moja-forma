MOJA FORMA — OCR PRZEPISÓW I BAZA STARTOWA v2

Co dodano:
- wybór obrazu z galerii Androida (ACTION_OPEN_DOCUMENT),
- lokalne rozpoznawanie tekstu przez Google ML Kit Text Recognition (model dołączony do aplikacji; bez płatnego API),
- odczyt tekstu do formularza: nazwa, potencjalne składniki, gramatury i instrukcja do ręcznej korekty,
- możliwość zachowania wybranego zdjęcia przepisu w pomniejszonej postaci,
- kategorie: Śniadania, Obiady, Kolacje, Przekąski, Desery,
- 25 autorskich przepisów startowych (po 5 w każdej kategorii),
- zachowanie wcześniej zapisanych przepisów — baza startowa jest dopisywana, a nie nadpisuje istniejących wpisów.

Ważne:
- OCR może pomylić tekst, gramatury lub kolejność. Zawsze sprawdź pola przed zapisaniem.
- Wartości kcal w bazie startowej są orientacyjne; nie są wynikiem laboratoryjnym ani automatycznym wyliczeniem z pełnej bazy składników.
- W tej wersji zdjęcie i rozpoznany tekst są zapisywane po zatwierdzeniu przepisu. Kalorie należy wpisać/sprawdzić samodzielnie; automatyczne liczenie makro z gramatur to osobny kolejny etap.
- OCR jest lokalny i działa bez internetu po zainstalowaniu aplikacji.

Budowanie:
1. Wgraj zawartość projektu do repozytorium albo archiwum ZIP do repozytorium.
2. W workflow, który rozpakowuje ZIP, ustaw jego dokładną nazwę.
3. GitHub Actions: Gradle 8.9, Java 17, polecenie gradle assembleDebug.
4. Pobierz artefakt moja-forma-apk.

Przed aktualizacją istniejącej instalacji wyeksportuj kopię danych w aplikacji (Więcej -> Zrób kopię danych). Jeśli Android odrzuci aktualizację z powodu innego podpisu APK, odinstalowanie starej wersji usunie lokalne dane aplikacji — najpierw wykonaj kopię.
