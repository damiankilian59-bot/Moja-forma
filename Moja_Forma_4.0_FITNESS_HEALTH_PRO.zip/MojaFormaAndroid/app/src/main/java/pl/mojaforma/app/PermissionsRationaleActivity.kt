package pl.mojaforma.app

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.widget.ScrollView
import android.widget.TextView

/** Explains the limited Health Connect data access requested by Moja Forma. */
class PermissionsRationaleActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val content = TextView(this).apply {
            text = "Moja Forma – wykorzystanie danych Health Connect\n\n" +
                "Aplikacja odczytuje wyłącznie liczbę kroków oraz zapisane sesje snu, " +
                "aby wyświetlać dzienną aktywność i regenerację. Dane są używane " +
                "wewnątrz aplikacji do prezentowania statystyk i historii.\n\n" +
                "Odczyt w tle służy aktualizowaniu tych samych statystyk, gdy aplikacja " +
                "nie jest otwarta. Moja Forma nie zapisuje ani nie udostępnia tych " +
                "danych innym podmiotom. Dostęp można w każdej chwili cofnąć " +
                "w ustawieniach Health Connect.\n\n" +
                "Dane zdrowotne pozostają pod kontrolą użytkownika. Bez przyznanej " +
                "zgody aplikacja nie odczytuje kroków ani snu."
            textSize = 18f
            setPadding(48, 48, 48, 48)
            gravity = Gravity.START
        }
        setContentView(ScrollView(this).apply { addView(content) })
    }
}
