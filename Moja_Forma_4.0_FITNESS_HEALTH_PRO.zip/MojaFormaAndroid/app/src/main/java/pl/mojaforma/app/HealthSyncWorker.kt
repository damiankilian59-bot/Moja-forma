package pl.mojaforma.app

import android.content.Context
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.SleepSessionRecord
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.request.AggregateRequest
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import java.time.Duration
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import org.json.JSONObject

/** Periodic background read. It never requests permissions; it only uses grants made by the user. */
class HealthSyncWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        return try {
            if (HealthConnectClient.getSdkStatus(applicationContext) != HealthConnectClient.SDK_AVAILABLE) return Result.retry()
            val client = HealthConnectClient.getOrCreate(applicationContext)
            val required = setOf(
                HealthPermission.getReadPermission(StepsRecord::class),
                HealthPermission.getReadPermission(SleepSessionRecord::class)
            )
            if (!client.permissionController.getGrantedPermissions().containsAll(required)) return Result.success()

            val zone = ZoneId.systemDefault()
            val now = Instant.now()
            val date = LocalDate.now(zone)
            val start = date.atStartOfDay(zone).toInstant()
            val aggregate = client.aggregate(AggregateRequest(setOf(StepsRecord.COUNT_TOTAL), TimeRangeFilter.between(start, now)))
            val steps = aggregate[StepsRecord.COUNT_TOTAL] ?: 0L

            // Include overnight sessions that started on the previous calendar day.
            val sleepStart = now.minus(Duration.ofHours(36))
            val records = client.readRecords(ReadRecordsRequest(
                recordType = SleepSessionRecord::class,
                timeRangeFilter = TimeRangeFilter.between(sleepStart, now)
            )).records
            val intervals = records.mapNotNull { r ->
                val s = if (r.startTime.isBefore(sleepStart)) sleepStart else r.startTime
                val e = if (r.endTime.isAfter(now)) now else r.endTime
                if (e.isAfter(s)) s to e else null
            }.sortedBy { it.first }
            var minutes = 0L
            var s: Instant? = null
            var e: Instant? = null
            for ((a, b) in intervals) {
                if (s == null) { s = a; e = b }
                else if (!a.isAfter(e!!)) { if (b.isAfter(e!!)) e = b }
                else { minutes += Duration.between(s!!, e!!).toMinutes(); s = a; e = b }
            }
            if (s != null && e != null) minutes += Duration.between(s!!, e!!).toMinutes()
            val json = JSONObject().put("ok", true).put("date", date.toString())
                .put("steps", steps).put("sleepHours", Math.round(minutes / 60.0 * 10.0) / 10.0)
                .put("source", "Health Connect · synchronizacja w tle").toString()
            applicationContext.getSharedPreferences("health_sync", Context.MODE_PRIVATE)
                .edit().putString("latest_health_json", json).putLong("last_sync", System.currentTimeMillis()).apply()
            Result.success()
        } catch (_: SecurityException) { Result.success() }
          catch (_: Exception) { Result.retry() }
    }
}
