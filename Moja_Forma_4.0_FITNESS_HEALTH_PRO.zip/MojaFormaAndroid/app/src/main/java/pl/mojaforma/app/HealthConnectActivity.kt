package pl.mojaforma.app

import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.lifecycle.lifecycleScope
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.PermissionController
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.SleepSessionRecord
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.request.AggregateRequest
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import java.time.Duration
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import kotlinx.coroutines.launch
import org.json.JSONObject

/** Foreground Health Connect bridge. It only reads data after the user grants access. */
class HealthConnectActivity : ComponentActivity() {
    private val requestedPermissions = setOf(
        HealthPermission.getReadPermission(StepsRecord::class),
        HealthPermission.getReadPermission(SleepSessionRecord::class),
        HealthPermission.PERMISSION_READ_HEALTH_DATA_IN_BACKGROUND
    )

    private val permissionLauncher = registerForActivityResult(
        PermissionController.createRequestPermissionResultContract()
    ) { grantedPermissions ->
        lifecycleScope.launch {
            if (grantedPermissions.containsAll(requestedPermissions)) {
                HealthSyncScheduler.enable(this@HealthConnectActivity)
                readHealthData()
            }
            else finishWithError("Nie przyznano dostępu do kroków, snu i odczytu w tle w Health Connect.")
        }
    }

    private lateinit var client: HealthConnectClient

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT < 28) {
            finishWithError("Health Connect wymaga Androida 9 lub nowszego.")
            return
        }
        when (HealthConnectClient.getSdkStatus(this)) {
            HealthConnectClient.SDK_AVAILABLE -> {
                client = HealthConnectClient.getOrCreate(this)
                lifecycleScope.launch { checkPermissionsAndContinue() }
            }
            HealthConnectClient.SDK_UNAVAILABLE_PROVIDER_UPDATE_REQUIRED ->
                finishWithError("Zainstaluj lub zaktualizuj aplikację Health Connect w Google Play, a następnie spróbuj ponownie.")
            else -> finishWithError("Health Connect nie jest dostępny na tym urządzeniu.")
        }
    }

    private suspend fun checkPermissionsAndContinue() {
        try {
            val granted = client.permissionController.getGrantedPermissions()
            if (granted.containsAll(requestedPermissions)) {
                HealthSyncScheduler.enable(this@HealthConnectActivity)
                readHealthData()
            } else if (intent.getBooleanExtra("ask_permission", false)) {
                permissionLauncher.launch(requestedPermissions)
            } else {
                finishWithError("Brak zgody na odczyt. Naciśnij „Połącz z Health Connect”, aby nadać uprawnienia do kroków, snu i synchronizacji w tle.")
            }
        } catch (e: Exception) {
            finishWithError("Błąd Health Connect: ${e.localizedMessage ?: "nieznany problem"}")
        }
    }

    private suspend fun readHealthData() {
        try {
            val zone = ZoneId.systemDefault()
            val now = Instant.now()
            val today = LocalDate.now(zone)
            val dayStart = today.atStartOfDay(zone).toInstant()
            val stepsResponse = client.aggregate(
                AggregateRequest(
                    metrics = setOf(StepsRecord.COUNT_TOTAL),
                    timeRangeFilter = TimeRangeFilter.between(dayStart, now)
                )
            )
            val steps = stepsResponse[StepsRecord.COUNT_TOTAL] ?: 0L

            // Read the last 36 hours so that a sleep session started yesterday is included.
            val sleepStart = now.minus(Duration.ofHours(36))
            val sleepResponse = client.readRecords(
                ReadRecordsRequest(
                    recordType = SleepSessionRecord::class,
                    timeRangeFilter = TimeRangeFilter.between(sleepStart, now)
                )
            )
            val intervals = sleepResponse.records
                .mapNotNull { record ->
                    val start = if (record.startTime.isBefore(sleepStart)) sleepStart else record.startTime
                    val end = if (record.endTime.isAfter(now)) now else record.endTime
                    if (end.isAfter(start)) start to end else null
                }
                .sortedBy { it.first }

            // Merge overlaps from multiple providers to avoid counting the same sleep twice.
            var totalSleepMinutes = 0L
            var currentStart: Instant? = null
            var currentEnd: Instant? = null
            for ((start, end) in intervals) {
                if (currentStart == null) {
                    currentStart = start
                    currentEnd = end
                } else if (!start.isAfter(currentEnd!!)) {
                    if (end.isAfter(currentEnd!!)) currentEnd = end
                } else {
                    totalSleepMinutes += Duration.between(currentStart!!, currentEnd!!).toMinutes()
                    currentStart = start
                    currentEnd = end
                }
            }
            if (currentStart != null && currentEnd != null) {
                totalSleepMinutes += Duration.between(currentStart!!, currentEnd!!).toMinutes()
            }

            val result = JSONObject()
                .put("ok", true)
                .put("date", today.toString())
                .put("steps", steps)
                .put("sleepHours", Math.round((totalSleepMinutes / 60.0) * 10.0) / 10.0)
                .put("source", "Health Connect")
            val output = Intent().putExtra("health_json", result.toString())
            setResult(Activity.RESULT_OK, output)
            finish()
        } catch (e: SecurityException) {
            finishWithError("Health Connect nie udostępnił danych. Sprawdź uprawnienia w ustawieniach zdrowia.")
        } catch (e: Exception) {
            finishWithError("Nie udało się pobrać danych: ${e.localizedMessage ?: "błąd odczytu"}")
        }
    }

    private fun finishWithError(message: String) {
        setResult(Activity.RESULT_CANCELED, Intent().putExtra("health_error", message))
        finish()
    }
}

