MOJA FORMA 2.0.2 — PROJEKT ANDROID
=================================

ZACHOWANE FUNKCJE I DANE
- Identyfikator Android: pl.mojaforma.app.
- Dane aplikacji pozostają w localStorage pod kluczem mojForma.
- Dieta, kalendarz posiłków, przepisy, OCR przepisu, lista zakupów, skaner kodów i katalog Open Food Facts.
- Dziennik treningowy, mapa mięśni, pomiary, zdjęcia postępów, ręczne zapisy snu i aktywności.
- Asystent offline, raport 7/30 dni, CSV, wydruk raportu, kopia i przywracanie JSON.
- Jasny/ciemny motyw i zwijane menu.

NOWE W 2.0.3
- Integracja Health Connect: po jednorazowym nadaniu zgody aplikacja pobiera sumę kroków z bieżącego dnia oraz sesje snu z ostatnich 36 godzin. Połączenie odświeża się przy uruchomieniu aplikacji i przyciskiem w sekcji Zdrowie.
- Dane automatyczne są oznaczone źródłem Health Connect i zapisywane w istniejącym lokalnym magazynie. Ręczne wpisy snu nie są nadpisywane. Odmowa zgody nie blokuje pozostałych funkcji.
- Wymaga Androida 9 lub nowszego oraz aplikacji/systemowej usługi Health Connect. Android 13 i starsze mogą wymagać instalacji Health Connect z Google Play. Zegarek lub aplikacja fitness musi synchronizować dane do Health Connect.
- Odczyt odbywa się na pierwszym planie przy otwarciu aplikacji; nie wdrożono ciągłego odczytu w tle.

NOWE W 2.0.2
- Przypomnienia systemowe Android: codzienne i jednorazowe. Codzienne przypomnienia są odtwarzane po ponownym uruchomieniu telefonu. Android może opóźniać je przez oszczędzanie energii. W Androidzie 13+ trzeba zezwolić na powiadomienia.
- Analiza zdjęcia posiłku przez skonfigurowany model AI obsługujący obraz. Wyniki gramatur i kalorii są szacunkowe i wymagają potwierdzenia.
- Backend AI przyjmuje zdjęcie, a klucz dostawcy pozostaje na serwerze. Można dodatkowo ustawić AI_APP_TOKEN.

WYMAGANE USŁUGI ZEWNĘTRZNE
- AI online: uruchom backend-ai na hostingu HTTPS, ustaw AI_API_KEY jako tajną zmienną środowiskową hostingu, opcjonalnie AI_APP_TOKEN, a następnie wpisz adres serwera i token w aplikacji. Backend domyślnie korzysta z modelu gpt-4o-mini, który obsługuje obrazy; dostępność i koszt zależą od dostawcy/konta.
- Skaner kodów odczytuje kod, a dane produktu pobiera z Open Food Facts; katalog może nie zawierać produktu.

NIE WDROŻONO JESZCZE
- Synchronizacji chmurowej, kont użytkowników i wielu profili.
- Automatycznych kopii na serwerze. Kopię JSON należy eksportować i przechowywać samodzielnie.
- Jednorazowe przypomnienia nie są odtwarzane po restarcie telefonu; codzienne są odtwarzane.

BEZPIECZEŃSTWO I AKTUALIZACJA
Nie zmieniono applicationId ani klucza localStorage. Zgodność aktualizacji zależy jednak od podpisu APK. Nie odinstalowuj starej wersji przed sprawdzeniem aktualizacji. Najpierw wyeksportuj kopię JSON. Klucza AI_API_KEY nie wpisuj do APK ani repozytorium. Backend wystawiaj wyłącznie przez HTTPS.

BUDOWANIE I TESTY
Projekt używa Android Gradle Plugin 8.9.1, Gradle 8.11.1, Kotlin 2.1.20, compileSdk 36 i JDK 17. Minimalny Android to API 26; Health Connect wymaga Androida 9/API 28 lub nowszego. Workflow .github/workflows/build-apk.yml uruchamia gradle assembleDebug i publikuje artefakt moja-forma-apk. W tej sesji sprawdzono składnię JavaScript (Node --check), składnię serwera Node.js, XML manifestu i archiwum ZIP. Nie uruchomiono lokalnej kompilacji Android, ponieważ środowisko nie ma Android SDK/Gradle. Wynik kompilacji musi potwierdzić GitHub Actions.
